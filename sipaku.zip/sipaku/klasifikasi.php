<!DOCTYPE html>
<html>
<?php include 'header.html'; ?>


<!--awal-->

<!--awal--> 
<div class="form-group">
    <div class="container" style="margin-left: 220px;">
      <div class="col-xs-12 col-sm-12 col-md-8">
        <div class="page-header">
        <h3 style="text-align:center; margin-top: 20px; ">Konsultasi</h3>
      </div>
<section id="tes_asma">
<center>
 <body> 
  <form method="post" action="perhitungan.php">   
  <p>&nbsp;</p>
 
          <div class="form-group">
            <label for="kt">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" required>
          </div>
<br>
          <div class="form-group">
            <label for="kt">Tempat Tanggal Lahir (Ex : Karawang, 27 Oktober 2000)</label>
            <input type="text" class="form-control" id="ttl" name="ttl" required>
          </div>
<br>
      <div class="form-group">
            <label for="kt">Alamat</label>
            <input type="text" class="form-control" id="alamat" name="alamat" required>
          </div>
<br>
       <div class="form-group">
           <label class="kt">1.Apakah Kulit anda Berjerawat?</label>
          <select class="form-control" name="input1">
            <option value="input1b">Tidak</option>
            <option value="input1a">Ya</option>
            
          </select>
        </td>
      </div>

      <div class="form-group">
           <label class="kt">2.Apakah Pori-pori kulit besar terutama di area hidung, pipi, dagu (T-Zone)</label>
          <select class="form-control" name="input2">
             <option value="input2b">Tidak</option>
            <option value="input2a">Ya</option>  
           
          </select>
        </td>
      </div>

        <div class="form-group">
           <label class="kt">3.Apakah Kulit di bagian wajah terlihat mengkilap</label>
          <select class="form-control" name="input3">
             <option value="input3b">Tidak</option>
            <option value="input3a">Ya</option>  
           
          </select>
        </td>
      </div>
        <div class="form-group">
           <label class="kt">4.Apakah Sering di tumbuhi Berjerawat</label>
          <select class="form-control" name="input4">
            <option value="input4b">Tidak</option>
            <option value="input4a">Ya</option>  
            
          </select>
        </td>
      </div>
 <div class="form-group">
           <label class="kt">5.Apakah Kulit anda kelihatan kering sekali</label>
          <select class="form-control" name="input5">
             <option value="input5b">Tidak</option>
            <option value="input5a">Ya</option>  
           
          </select>
        </td>
      </div>
       
        <div class="form-group">
           <label class="kt">6.Apakah Kulit anda mempunyai Pori Pori Besar</label>
          <select class="form-control" name="input6">
             <option value="input6b">Tidak</option>
            <option value="input6a">Ya</option>  
           
          </select>
        </td>
      </div>
      <div class="form-group">
           <label class="kt">7.Apakah Tekstur kulit wajah anda tipis </label>
          <select class="form-control" name="input7">
            <option value="input7b">Tidak</option>
            <option value="input7a">Ya</option>  
            
          </select>
        </td>
      </div>
      <div class="form-group">
           <label class="kt">8.Apakah Cepat menampakkan kerutan-kerutan</label>
          <select class="form-control" name="input8">
            <option value="input8b">Tidak</option>
            <option value="input8a">Ya</option>  
            
          </select>
        </td>
      </div>
      <div class="form-group">
           <label class="kt">9.Apakah Sebagian Kulit Kelihatan Berminyak?</label>
          <select class="form-control" name="input9">
             <option value="input9b">Tidak</option>
            <option value="input9a">Ya</option>  
           
          </select>
        </td>
      </div>
      <div class="form-group">
           <label class="kt">10.Apakah Sebagian Kulit Kelihatan Kering</label>
          <select class="form-control" name="input10">
             <option value="input10b">Tidak</option>
            <option value="input10a">Ya</option>  
           
          </select>
        </td>
      </div>
       <div class="form-group">
           <label class="kt">11.Apakah Kulit Kadang Berjerawat</label>
          <select class="form-control" name="input11">
            <option value="input11b">Tidak</option>
            <option value="input11a">Ya</option>  
            
          </select>
        </td>
      </div>
      <div class="form-group">
           <label class="kt">12.Apakah Kulit Mudah Alergi</label>
          <select class="form-control" name="input12">
            <option value="input12b">Tidak</option>
            <option value="input12a">Ya</option>  
            
          </select>
        </td>
      </div>
      <div class="form-group">
           <label class="kt">13.Apakah Kulit anda mudah iritasi dan terluka</label>
          <select class="form-control" name="input13">
            <option value="input13b">Tidak</option>
            <option value="input13a">Ya</option>  
            
          </select>
        </td>
      </div>
      <div class="form-group">
           <label class="kt">14.Apakah Kulit anda mudah terlihat merah</label>
          <select class="form-control" name="input14">
             <option value="input14b">Tidak</option>
            <option value="input14a">Ya</option>  
           
          </select>
        </td>
      </div>
    <button style="margin-top: 30px;"type="submit" value="Submit" class="btn btn-danger">Kalkulasi</button>
  
</form>
<br><br><br>
</section>



</body>
</html></center>