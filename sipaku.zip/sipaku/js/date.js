function setDatePicker(input){
  $(input).datetimepicker({
    format: "YYYY-MM-DD",
    useCurrent: false
  })
}