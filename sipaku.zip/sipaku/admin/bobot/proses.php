<?php
include '../_config/config.php';
 
	$idbobot = $_POST['idbobot'];
	$bobot = $_POST['bobot'];
    
 

	$query = "INSERT INTO bobot value ('$idbobot','$bobot')";
	 $result= mysqli_query($conn,$query);
	 if ($result) {
	    echo "
	    <script>
	    	alert('Data Berhasil Di Tambahkan');
	    	document.location.href='data.php';
	    </script>
	    ";
	  } else {
	    echo "
	    <script>
	    	alert('Data Gagal Di Tambahkan');
	    	document.location.href='data.php';
	    </script>
	    ";
	  }
	  mysqli_close($conn);
 
?>