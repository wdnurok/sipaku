<?php
include '../_config/config.php';

$id   = $_GET['idbobot'];
$query="DELETE from bobot where idbobot='$idbobot'";
mysqli_query($conn, $query);
header("location:data.php");
?>