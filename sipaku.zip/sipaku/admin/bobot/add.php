<?php include_once('../header.php'); ?>
<link rel="stylesheet" type="text/css" href="../_assets/css/style.css">

<?php include_once('../footer.php'); ?>

<div class="atas">
	<div class="container">
	<h1>bobot </h1>
	<h4>Tambah Data Bobot</h4>
</div>
</div>

		<div class="container" style="margin-left: 220px;">
		  <div class="col-xs-12 col-sm-12 col-md-8">
		  	<div class="page-header">
			  <h5>Tambah Bobot</h5>
			</div>
			
			    <form action="proses.php" method="post">
			    	<div class="form-group">
				    <label for="kt">Id Bobot</label>
				    <input type="text" class="form-control" id="idbobot" name="idbobot" required>
				  </div>
				  <div class="form-group">
				    <label for="kt">Nama Bobot</label>
				    <input type="text" class="form-control" id="bobot" name="bobot" required>
				  </div>
				  <button type="submit" class="btn btn-primary">Simpan</button>
				  <button type="button" onclick="location.href='data.php'" class="btn btn-success">Kembali</button>
				</form>
			  
		  </div>