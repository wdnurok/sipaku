<?php include_once('../header.php'); ?>
<link rel="stylesheet" type="text/css" href="../_assets/css/style.css">

<?php include_once('../footer.php'); ?>
<body>
<div class="atas">
<div class="container">
	<h1>Bobot</h1>
	<h4>Data Bobot</h4>
	<div class="pull-right">
		<a href="" class="btn btn-default me-md-2"><i class="glyphicon glyphicon-refresh"></i></a>
		<a href="add.php" class="btn btn-success "><i class="glyphicon glyphicon-plus"></i>Tambah Data</a>
	</div>
	<div style="margin-bottom: 20px;">
	<form class="form-inline" action="" method="post">
		<div class="form-group">
			<input type="text" name="pencarian" class="form-control" placeholder="pencarian">
		</div>
		<div class="form-group">
			<button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
		</div>
	</div>
	</form>
	<div class="table-responsive">
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>No.</th>
					<th>Id Bobot</th>
					<th>Bobot</th>
					<th><i class="glyphicon glyphicon-cog"></i></th>
				</tr>
			</thead>
			
		<?php
				$batas = 3;
				$hal = @$_GET['hal'];
				if (empty($hal)) {
					$posisi =0;
					$hal=1;
				}else{
					$posisi = ($hal - 1) * $batas;
				}
				if ($_SERVER['REQUEST_METHOD'] == "POST") {
					$pencarian = trim(mysqli_real_escape_string($conn, $_POST['pencarian']));
					if ($pencarian !='') {
						$sql = "SELECT * FROM bobot WHERE bobot LIKE '%$pencarian%'";
						$query = $sql;
						$queryJml = $sql;
				}else{
					$query = "SELECT * FROM bobot LIMIT $posisi, $batas";
					$queryJml="SELECT * FROM bobot";
					$no = $posisi + 1;
				}
				}else{
					$query = "SELECT * FROM bobot LIMIT $posisi,$batas";
					$queryJml="SELECT * FROM bobot";
					$no = $posisi + 1;
				}
				$no=1;
				$sql_bobot = mysqli_query($conn, $query) or die (mysqli_error($conn));
				if (mysqli_num_rows($sql_bobot)>0) {
				while ($data = mysqli_fetch_array($sql_bobot)) { ?>
					<tr>
						<td><?=$no++?></td>
						<td><?=$data['idbobot']?></td>
						<td><?=$data['bobot']?></td>
						<td class="text-center">
							<a href="edit.php?id=<?=$data['idbobot']?>" class="btn btn-warning btn-xs"><i class="glyphicon glyphicon-edit"></i></a>
							<a href="del.php?id=<?=$data['idbobot']?>" onclick="return confirm('Yakin Akan Menghapus?')"class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-trash"></i></a>
						</td>
					</tr>
					<?php
					}
				}else{
					echo"<tr><td colspan=\"4\" align=\"center\">DATA TIDAK DITEMUKAN</td></tr>";
				}
				?>
			</tbody>
		</table>
	</div>
	

		</div>
</div>
</body>
