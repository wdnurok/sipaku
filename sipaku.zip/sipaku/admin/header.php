<?php

require_once "_config/config.php";
if (!isset($_SESSION['username'])) {
     echo "<script>window.location='".base_url('auth/login.php')."';</script>";
}
	
?>

<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Dashboard</title>
	<!-- FONTAWESOME -->
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

	<!-- MY CSS -->
	<link href="<?=base_url('admin/_assets/css/style.css');?>"rel="stylesheet">
	<!-- Bootstrap -->
	<link href="<?=base_url('admin/_assets/css/bootstrap.min.css');?>"rel="stylesheet">
	<link href="<?=base_url('admin/_assets/css/simple-sidebar.css');?>"rel="stylesheet">
</head>
<body>
	<script src="<?=base_url('admin/_assets/js/jquery.js');?>"></script>
	<script src="<?=base_url('admin/_assets/js/bootstrap.min.js');?>"></script>
	<div class="navigation">
		<ul>
			<li>
				<a href="<?=base_url('admin/dashboardadm')?>">
					<span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
					<span class="title">Beranda</span>
				</a>
			</li>
			<li>
				<a href="<?=base_url('admin/user/data.php')?>">
					<span class="icon"><i class="fa fa-user" aria-hidden="true"></i></span>
					<span class="title">Info Admin</span>
				</a>
			</li>
			<li>
				<a href="<?=base_url('admin/jenis_kulit/data.php')?>">
					<span class="icon"><i class="fa fa-mask" aria-hidden="true"></i></span>
					
					<span class="title">Jenis Kulit</span>
				</a>
			</li>
			<li>
				<a href="<?=base_url('admin/gejala/data.php')?>">
					<span class="icon"><i class="fa fa-stethoscope" aria-hidden="true"></i></span>
					<span class="title">Gejala</span>
				</a>
			</li>
			
			<li>
				<a href="<?=base_url('admin/relasi/data.php')?>">
					<span class="icon"><i class="fa fa-globe" aria-hidden="true"></i></span>
					<span class="title">Relasi</span>
				</a>
			</li>
			
			<li>
				<a href="<?=base_url('admin/auth/logout.php')?>">
					<span class="icon"><i class="fa fa-sign-out" aria-hidden="true"></i></span>
					<span class="title">Sign Out</span>
				</a>
			</li>
		</ul>
	

