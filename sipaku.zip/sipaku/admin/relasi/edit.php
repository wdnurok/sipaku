<?php include_once('../header.php'); ?>
<link rel="stylesheet" type="text/css" href="../_assets/css/style.css">

<?php include_once('../footer.php'); ?>

<div class="atas">
	<div class="container">
	<h1>basis_aturan</h1>
	<h4>Edit Data basis_aturan</h4>
</div>
</div>

		<div class="container" style="margin-left: 220px;">
		  <div class="col-xs-12 col-sm-12 col-md-8">
		  	<?php
		  	$id_gejala = @$_GET['id_gejala'];
		  	$sql_basis_aturan= mysqli_query($conn, "SELECT * FROM basis_aturan WHERE id_gejala = '$id_gejala'") or die (mysqli_error($conn));
		  	$data=mysqli_fetch_array($sql_basis_aturan);

		  	?>

		  	<div class="page-header">
			  <h5>Edit Data Report</h5>
			</div>
			
			    <form action="prosesedit.php" method="post">
			    	<div class="form-group">
				    <label for="kt">Id Gejala</label>
				    <input type="hidden" name="id_gejala" value="<?=$data['id_gejala']?>">
				    <input type="text" class="form-control" id="id_gejala" value="<?=$data['id_gejala']?>" name="id_gejala" required>
				  </div>
				  <div class="form-group">
				    <label for="kt">Pertanyaan</label>
				    <input type="hidden" name="pertanyaan" value="<?=$data['pertanyaan']?>">
				    <input type="text" class="form-control" id="pertanyaan" value="<?=$data['pertanyaan']?>" name="pertanyaan" required>
				  </div>

				  <div class="form-group">
				    <label for="kt">Normal</label>
				    <input type="hidden" name="normal" value="<?=$data['normal']?>">
				    <input type="text" class="form-control" id="normal" value="<?=$data['normal']?>" name="normal" required>
				  </div>

				 <div class="form-group">
				    <label for="kt">Berminyak</label>
				    <input type="hidden" name="berminyak" value="<?=$data['berminyak']?>">
				    <input type="text" class="form-control" id="berminyak" value="<?=$data['berminyak']?>" name="berminyak" required>
				  </div>
				  <div class="form-group">
				    <label for="kt">Sensitif</label>
				    <input type="hidden" name="sensitif" value="<?=$data['sensitif']?>">
				    <input type="text" class="form-control" id="sensitif" value="<?=$data['sensitif']?>" name="sensitif" required>
				  </div>
				  <div class="form-group">
				    <label for="kt">Kombinasi</label>
				    <input type="hidden" name="kombinasi" value="<?=$data['kombinasi']?>">
				    <input type="text" class="form-control" id="kombinasi" value="<?=$data['kombinasi']?>" name="kombinasi" required>
				  </div>
				  <div class="form-group">
				    <label for="kt">Kering</label>
				    <input type="hidden" name="kering" value="<?=$data['kering']?>">
				    <input type="text" class="form-control" id="kering" value="<?=$data['kering']?>" name="kering" required>
				  </div>

				 

				  <button type="submit" class="btn btn-primary">Simpan</button>
				  <button type="button" onclick="location.href='data.php'" class="btn btn-success">Kembali</button>
				</form>
			  
		  </div>