<?php
include '../_config/config.php';

$idrelasi   = $_GET['idrelasi'];
$query="DELETE from relasi where idrelasi='$idrelasi'";
mysqli_query($conn, $query);
header("location:data.php");
?>