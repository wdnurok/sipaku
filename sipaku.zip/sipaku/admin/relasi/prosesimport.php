<?php
if (isset($_POST['import'])){
	$file = $_FILES['file']['name'];
	$ekstensi = explode(".", $file);
	$file_name = "file-".round(microtime(true)).".".end($ekstensi);
	$sumber= $_FILES['file'] ['tmp_name'];
	$target_dir="../_file";
	$target_file= $target_dir.$target_file;
	$upload=move_uploaded_file($sumber, $target_file);
	if ($upload) {
		echo "Upload Sukses";

	}else{
		echo "Upload Gagal";
	}
}
?>