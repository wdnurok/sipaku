<?php include_once('../header.php'); ?>
<link rel="stylesheet" type="text/css" href="../_assets/css/style.css">

<?php include_once('../footer.php'); ?>

<div class="atas">
	<div class="container">
	<h1>Report Data</h1>
	<h4>Impot Data</h4>
</div>
</div>

		<div class="container" style="margin-left: 220px;">
		  <div class="col-xs-12 col-sm-12 col-md-8">
		  	<div class="page-header">
			  <h5>Import Data</h5>
			</div>
			
			    <form action="proses.php" method="post" enctype="multipart/form-data">
				  <div class="form-group">
				    <label for="file">File Excel</label>
				    <input type="file" class="form-control" id="file" name="file" required>
				  </div>
				  <div class="form-group pull-right" style="margin: 10px;">
				  	<input type="submit" name="add" value="Simpan" class="btn btn-primary">
				  </div>
				  <div class="form-group pull-right" style="margin: 10px;">
				  <button type="button" onclick="location.href='data.php'" class="btn btn-success">Kembali</button>
				</div>
				</form>
			  
		  </div>