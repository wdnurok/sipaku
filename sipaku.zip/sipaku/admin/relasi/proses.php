<?php
include '../_config/config.php';
 
$idrelasi = $_POST['idrelasi'];
	$namagejala = $_POST['namagejala'];
	$bobot = $_POST['bobot'];
	$namakulit = $_POST['namakulit'];
	

	$query = "INSERT INTO relasi value ('$idrelasi','$namagejala','$bobot','$namakulit')";
	 $result= mysqli_query($conn,$query) or die (mysqli_error($conn));
	 if ($result) {
	    echo "
	    <script>
	    	alert('Data Berhasil Di Tambahkan');
	    	document.location.href='data.php';
	    </script>
	    ";
	  } else {
	    echo "
	    <script>
	    	alert('Data Gagal Di Tambahkan');
	    	document.location.href='data.php';
	    </script>
	    ";
	  }
	  mysqli_close($conn);
 
?>