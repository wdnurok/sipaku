<?php 

include '../_config/config.php';
 
$id_gejala = $_POST['id_gejala'];
$pertanyaan = $_POST['pertanyaan'];
$normal = $_POST['normal'];
$berminyak = $_POST['berminyak'];
$sensitif = $_POST['sensitif'];
$kombinasi = $_POST['kombinasi'];
$kering = $_POST['kering'];
$query = "UPDATE basis_aturan SET pertanyaan = '$pertanyaan', normal = '$normal', berminyak = '$berminyak', sensitif = '$sensitif', kombinasi = '$kombinasi', kering = '$kering' WHERE id_gejala= '$id_gejala'";
$result= mysqli_query($conn,$query);
 if ($result) {
	    echo "
	    <script>
	    	alert('Data Berhasil Di Ubah');
	    	document.location.href='data.php';
	    </script>
	    ";
	  } else {
	    echo "
	    <script>
	    	alert('Data Gagal Di Ubah');
	    	document.location.href='data.php';
	    </script>
	    ";
	  }
	  mysqli_close($conn);
 


?>