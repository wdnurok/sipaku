<?php include_once('../header.php'); ?>
<link rel="stylesheet" type="text/css" href="../_assets/css/style.css">

<?php include_once('../footer.php'); ?>

<div class="atas">
	<div class="container">
	<h1>Relasi</h1>
	<h4>Tambah Data Relasi</h4>
</div>
</div>
  <form action="proses.php" method="post">
	<div class="form-group">
		<div class="container" style="margin-left: 220px;">
		  <div class="col-xs-12 col-sm-12 col-md-8">
		  	<div class="page-header">
			  <h5>Tambah Relasi</h5>
			</div>
			
			    <form action="proses.php" method="post">
				  
			    	<div class="form-group">
				    <label for="kt">ID Gejala</label>
				    <input type="text" class="form-control" id="id_gejala" name="id_gejala" required>
				    
				  </div>
				  <div class="form-group">
				    
				   <div class="form-group">
				    <label for="kt">Pertanyaan</label>
				    <input type="text" class="form-control" id="pertanyaan" name="pertanyaan" required>
				  </div>
			   	 <div class="form-group">
				    <label for="kt">Normal</label>
				    <input type="text" class="form-control" id="normal" name="normal" required>
				  </div>
				   <div class="form-group">
				    <label for="kt">Berminyak</label>
				    <input type="text" class="form-control" id="berminyak" name="berminyak" required>
				  </div>
				   <div class="form-group">
				    <label for="kt">Sensitif</label>
				    <input type="text" class="form-control" id="sensitif" name="sensitif" required>
				  </div>
				   <div class="form-group">
				    <label for="kt">Kombinasi</label>
				    <input type="text" class="form-control" id="kombinasi" name="kombinasi" required>
				  </div>
				   <div class="form-group">
				    <label for="kt">Kering</label>
				    <input type="text" class="form-control" id="kering" name="kering" required>
				  </div>
				  

				 
				  <button type="submit" class="btn btn-primary">Simpan</button>
				  <button type="button" onclick="location.href='data.php'" class="btn btn-success">Kembali</button>
			
			  </div>
			</div>
		</div>
		  </div>