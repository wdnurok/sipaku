<?php

require_once "../_config/config.php";
if (isset($_SESSION['user'])) {
    echo "<script>window.location='".base_url()."';</script>";
}else{

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">

    <meta name="author" content="">

    <title>Login</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?=base_url('admin/_assets/css/bootstrap.min.css');?>"rel="stylesheet">
    <!-- MY CSS -->
    <link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>
    <div class="jumbotron">
  
    </div>
</div>
    <div id="wrapper">
    <div class="container">
    <div class="row px-3">
      <div class="card" style="  padding-top: 100px;">
  <img src="image/bgbanner.jpeg" class="card-img-top" align="left">
  <div class="card-body">
          <form action="" class="inner-login" method="post">
          <h4 class="title text-center mt-4">
            Login Account
          </h4>
           <form class="form-box px-3">
            
            <?php
             if (isset($_POST['login'])) {
            $username = trim(mysqli_real_escape_string($conn, $_POST['username']));
            $password = md5(trim(mysqli_real_escape_string($conn, $_POST['password'])));
            $sql_login = mysqli_query($conn,"SELECT *FROM users WHERE username = '$username' AND password = '$password'") or die (mysqli_error($conn));
            if( mysqli_num_rows($sql_login) > 0){
              $_SESSION['username']= $username;
              echo "<script>window.location='".base_url('admin/dashboardadm')."';</script>";
          }else { ?>

            <div class="row">
            <div class="col-lg-6 col-lg-offset-3">
                <div class="alert alert-danger alert-dismissable" role="alert">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                    <strong>Login Gagal</strong> Username Password Salah
                    
                </div>
                
            </div>
            </div>
                

             <?php
            }
        }
        ?>

        
                    
                     
                    <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user "></i></span>
                    <input type="text" name="username" class="form-control" placeholder="Username" required>
                    </div>
                    <div style="margin-bottom: 20px;"></div>
                     <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-lock "></i></span>
                    <input type="password" name="password" class="form-control" placeholder="Password" required>
                    </div>
                    <div style="margin-bottom: 20px;"></div>
                    
                        <button type="submit" name="login"  value="login">LOGIN</button> 
                         
                        
                    </div>
                </form>
           </div>
        </div>
    </form>
</div>
</div>
</div>
</div>
</div>


        <script src="<?=base_url('_assets/js/jquery.js')?>"></script>
        <script src="<?=base_url('_assets/js/bootstrap.min.js')?>"></script>
</body>
</html>
<?php
}
?>

