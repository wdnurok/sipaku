<?php 

include '../_config/config.php';
 
$id = $_POST['id'];
$namagejala = $_POST['namagejala'];

$query = "UPDATE gejala SET namagejala = '$namagejala' WHERE idgejala= '$id'";
$result= mysqli_query($conn,$query);
 if ($result) {
	    echo "
	    <script>
	    	alert('Data Berhasil Di Ubah');
	    	document.location.href='data.php';
	    </script>
	    ";
	  } else {
	    echo "
	    <script>
	    	alert('Data Gagal Di Ubah');
	    	document.location.href='data.php';
	    </script>
	    ";
	  }
	  mysqli_close($conn);
 


?>