<?php include_once('../header.php'); ?>
<link rel="stylesheet" type="text/css" href="../_assets/css/style.css">

<?php include_once('../footer.php'); ?>

<div class="atas">
	<div class="container">
	<h1>gejala</h1>
	<h4>Edit Data gejala</h4>
</div>
</div>

		<div class="container" style="margin-left: 220px;">
		  <div class="col-xs-12 col-sm-12 col-md-8">
		  	<?php
		  	$id = @$_GET['id'];
		  	$sql_gejala= mysqli_query($conn, "SELECT * FROM gejala WHERE idgejala = '$id'") or die (mysqli_error($conn));
		  	$data=mysqli_fetch_array($sql_gejala);

		  	?>

		  	<div class="page-header">
			  <h5>Edit gejala</h5>
			</div>
			
			    <form action="prosesedit.php" method="post">
				  <div class="form-group">
				    <label for="kt">Nama gejala</label>
				    <input type="hidden" name="id" value="<?=$data['idgejala']?>">
				    <input type="text" class="form-control" id="namagejala" value="<?=$data['namagejala']?>" name="namagejala" required>
				  </div>
				  <div class="form-group">
				  	<input type="hidden" name="idrelasi" value="<?=$data['idrelasi']?>">
				   <label class="kt">Bobot</label>
				  <select class="form-control" name="bobot" value="<?=$data['bobot']?>">
					<?php
					
					$query = "SELECT * FROM bobot";
					$hasil = mysqli_query($conn,$query);
					while ($qtabel = mysqli_fetch_assoc($hasil))
					{
						echo '<option value="'.$qtabel['idbobot'].'|'.$qtabel['bobot'].'">'.$qtabel['idbobot'].'|'.$qtabel['bobot'].'</option>';				
					}
					?>
			   	</select>
				  </div>
				  <button type="submit" class="btn btn-primary">Simpan</button>
				  <button type="button" onclick="location.href='data.php'" class="btn btn-success">Kembali</button>
				</form>
			  
		  </div>