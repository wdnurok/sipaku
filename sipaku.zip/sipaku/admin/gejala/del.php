<?php
include '../_config/config.php';

$id   = $_GET['id'];
$query="DELETE from gejala where idgejala='$id'";
mysqli_query($conn, $query);
header("location:data.php");
?>