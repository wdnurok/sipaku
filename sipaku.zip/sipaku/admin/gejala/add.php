<?php include_once('../header.php'); ?>
<link rel="stylesheet" type="text/css" href="../_assets/css/style.css">

<?php include_once('../footer.php'); ?>

<div class="atas">
	<div class="container">
	<h1>gejala</h1>
	<h4>Tambah Data gejala</h4>
</div>
</div>

		<div class="container" style="margin-left: 220px;">
		  <div class="col-xs-12 col-sm-12 col-md-8">
		  	<div class="page-header">
			  <h5>Tambah gejala</h5>
			</div>
			
			    <form action="proses.php" method="post">
			    	<div class="form-group">
				    <label for="kt">ID gejala</label>
				    <input type="text" class="form-control" id="idgejala" name="idgejala">
				  </div>
				  <div class="form-group">
				    <label for="kt">Nama gejala</label>
				    <input type="text" class="form-control" id="namagejala" name="namagejala" required>
				  </div>
				   <div class="form-group">
				   <label class="kt">Bobot</label>
				  <select class="form-control" name="bobot">
					<?php
					
					$query = "SELECT * FROM bobot";
					$hasil = mysqli_query($conn,$query);
					while ($qtabel = mysqli_fetch_assoc($hasil))
					{
						echo '<option value="'.$qtabel['idbobot'].'|'.$qtabel['bobot'].'">'.$qtabel['idbobot'].'|'.$qtabel['bobot'].'</option>';			
					}
					?>
			   	</select>
				  </div>
				  <button type="submit" class="btn btn-primary">Simpan</button>
				  <button type="button" onclick="location.href='data.php'" class="btn btn-success">Kembali</button>
				</form>
			  
		  </div>