<?php
include '../_config/config.php';
 
	$idkulit=$_POST['idkulit'];
	$namakulit=$_POST['namakulit'];
	$definisi=$_POST['definisi'];
    $solusi=$_POST['solusi'];
    
 

	$query = "INSERT INTO kulit value ('$idkulit','$namakulit','$definisi','$solusi')";
	 $result= mysqli_query($conn,$query)or die (mysqli_error($conn));
	 if ($result) {
	    echo "
	    <script>
	    	alert('Data Berhasil Di Tambahkan');
	    	document.location.href='data.php';
	    </script>
	    ";
	  } else {
	    echo "
	    <script>
	    	alert('Data Gagal Di Tambahkan');
	    	document.location.href='data.php';
	    </script>
	    ";
	  }
	  mysqli_close($conn);
 
?>