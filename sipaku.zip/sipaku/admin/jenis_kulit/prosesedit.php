<?php 

include '../_config/config.php';
 
$id = $_POST['id'];
$namakulit = $_POST['namakulit'];
$definisi=$_POST['definisi'];
$solusi=$_POST['solusi'];
    
$query = "UPDATE kulit SET namakulit = '$namakulit', definisi = '$definisi',solusi = '$solusi' WHERE idkulit= '$id'";
$result= mysqli_query($conn,$query);
 if ($result) {
	    echo "
	    <script>
	    	alert('Data Berhasil Di Ubah');
	    	document.location.href='data.php';
	    </script>
	    ";
	  } else {
	    echo "
	    <script>
	    	alert('Data Gagal Di Ubah');
	    	document.location.href='data.php';
	    </script>
	    ";
	  }
	  mysqli_close($conn);
 


?>