<?php include_once('../header.php'); ?>
<link rel="stylesheet" type="text/css" href="../_assets/css/style.css">

<?php include_once('../footer.php'); ?>

<div class="atas">
	<div class="container">
	<h1>kulit</h1>
	<h4>Edit Data kulit</h4>
</div>
</div>

		<div class="container" style="margin-left: 220px;">
		  <div class="col-xs-12 col-sm-12 col-md-8">
		  	<?php
		  	$id = @$_GET['id'];
		  	$sql_kulit= mysqli_query($conn, "SELECT * FROM kulit WHERE idkulit = '$id'") or die (mysqli_error($conn));
		  	$data=mysqli_fetch_array($sql_kulit);

		  	?>

		  	<div class="page-header">
			  <h5>Edit kulit</h5>
			</div>
			
			    <form action="prosesedit.php" method="post">
				  <div class="form-group">
				    <label for="kt">Nama kulit</label>
				    <input type="hidden" name="id" value="<?=$data['idkulit']?>">
				    <input type="text" class="form-control" id="namakulit" value="<?=$data['namakulit']?>" name="namakulit" required>
				  </div>
				  <div class="form-group">
				    <label for="kt">Definisi</label>
				    <input type="hidden" name="id" value="<?=$data['idkulit']?>">
				  <input type="text" class="form-control" id="definisi" value="<?=$data['definisi']?>" name="definisi" required>
				  </div>
				  <div class="form-group">
				    <label for="kt">Solusi</label>
				    <input type="hidden" name="id" value="<?=$data['idkulit']?>">
				  <input type="text" class="form-control" id="solusi" value="<?=$data['solusi']?>" name="solusi" required>
				  </div>
				  <button type="submit" class="btn btn-primary">Simpan</button>
				  <button type="button" onclick="location.href='data.php'" class="btn btn-success">Kembali</button>
				</form>
			  
		  </div>