<?php
include '../_config/config.php';

$id   = $_GET['id'];
$query="DELETE from kulit where idkulit='$id'";
mysqli_query($conn, $query);
header("location:data.php");
?>