<?php

require_once "_config/config.php";
echo "<script>window.location='".base_url('admin/auth/login.php')."';</script>";

?>
