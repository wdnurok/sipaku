
<?php include_once('../header.php'); ?>
<link rel="stylesheet" type="text/css" href="../_assets/css/style.css">



<?php include_once('../footer.php'); ?>

<div class="row">
	<div class="container">
<h1>Dashboard</h1>
<p>Selamat Datang <?=$_SESSION['username'];?></p>	
</div>
</div>
