<?php include_once('../header.php'); ?>
<link rel="stylesheet" type="text/css" href="../_assets/css/style.css">

<?php include_once('../footer.php'); ?>

<div class="atas">
	<div class="container">
	<h1>Admin</h1>
	<h4>Tambah Data Admin</h4>
</div>
</div>

		<div class="container" style="margin-left: 220px;">
		  <div class="col-xs-12 col-sm-12 col-md-8">
		  	<div class="page-header">
			  <h5>Tambah Admin</h5>
			</div>
			
			    <form action="proses.php" method="post">
			      <div class="form-group">
				    <label for="kt">Username</label>
				    <input type="text" class="form-control" id="" name="username" required>
				  </div>
				  <div class="form-group">
				    <label for="kt">Nama Users</label>
				    <input type="text" class="form-control" id="" name="namausers" required>
				  </div>
				   <div class="form-group">
				    <label for="kt">Password</label>
				    <input type="password" class="form-control" id="" name="password" required>
				  </div>
				 
				  <label class="kt">Level User</label>
				      <select class="form-control" name="leveluser">
				        <option value="Admin">Admin</option>
				        <option value="Member">Member</option>
				      </select>
				    </div>
				  </div>

				  <button type="submit" class="btn btn-primary" style="margin-left: 250px; margin-top: 20px;">Simpan</button>
				  <button type="button" onclick="location.href='data.php'" class="btn btn-success" style="margin-top: 20px;">Kembali</button>
				</form>
			  
		  </div>