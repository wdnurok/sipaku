<?php
include '../_config/config.php';

$username   = $_GET['username'];
$query="DELETE from users where username='$username'";
mysqli_query($conn, $query);
header("location:data.php");
?>